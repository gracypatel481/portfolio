const menuBtn=document.getElementById("menuBtn");
const mobileNav=document.getElementById("mobileNav");
const themeBtn=document.getElementById("themeBtn");

menuBtn.addEventListener("click",()=>{
  const open=mobileNav.classList.toggle("open");
  menuBtn.setAttribute("aria-expanded",open);
});
document.querySelectorAll(".mobile-nav a").forEach(a=>a.addEventListener("click",()=>mobileNav.classList.remove("open")));

themeBtn.addEventListener("click",()=>{
  document.body.classList.toggle("dark-mode");
  localStorage.setItem("gracy-theme",document.body.classList.contains("dark-mode")?"dark":"light");
});
if(localStorage.getItem("gracy-theme")==="dark") document.body.classList.add("dark-mode");

document.querySelectorAll("[data-top]").forEach(btn=>btn.addEventListener("click",()=>window.scrollTo({top:0,behavior:"smooth"})));

const floating=document.querySelector(".floating-top");
window.addEventListener("scroll",()=>{
  floating.style.display=window.scrollY>600?"block":"none";
});

document.querySelectorAll('a[href^="#"]').forEach(link=>{
  link.addEventListener("click",e=>{
    const el=document.querySelector(link.getAttribute("href"));
    if(el){e.preventDefault();el.scrollIntoView({behavior:"smooth"});}
  });
});
